puts = require('sys').puts;
for (var i = 0; i < 10; i++) {
  puts('count ' + i);
}
