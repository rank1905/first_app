require("../common");

// üäö

puts("Σὲ γνωρίζω ἀπὸ τὴν κόψη");

assert.equal(true,  /Hellö Wörld/.test("Hellö Wörld") );

