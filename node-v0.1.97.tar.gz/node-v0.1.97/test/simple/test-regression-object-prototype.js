var sys = require('sys');

//sys.puts('puts before');

Object.prototype.xadsadsdasasdxx = function () {
};

sys.puts('puts after');
